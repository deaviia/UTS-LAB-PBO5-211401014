/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package iklcbank;

import java.util.Date;
import java.util.Scanner;

public class IKLCBank {
    static final int MAX_ACCOUNTS = 100;
    static Account[] accounts = new Account[MAX_ACCOUNTS];
    static int numAccounts = 0;
    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;

        boolean quit = false;
        while (!quit) {
            System.out.println("+--------- Selamat Datang di Bank IKLC --------+");
            System.out.println("|1. Registrasi Akun                            |");
            System.out.println("|2. Transfer                                   |");
            System.out.println("|3. Rekening Deposito/Setor Tunai              |");
            System.out.println("|4. Cek Saldo                                  |");
            System.out.println("|5. Keluar                                     |");
            System.out.println("+----------------------------------------------+");
            System.out.print("Pilih menu (1-4): ");
            choice = input.nextInt();
            
            switch (choice) {
                case 1:
                    daftarAkun();
                    break;
                case 2:
                    kirimAkun();
                    break;
                case 3:
                    rekeningDeposito();
                    break;
                case 4:
                    cekSaldo();
                    break;
                case 5:
                    System.out.println("Terimakasih sudah menggunakan Bank IKLC..");
                    quit = true;
                    break;
                default:
                    System.out.println("Pilihan Anda tidak tersedia!");
                    break;
            }
        }
    }

    private static void daftarAkun() {
        System.out.print("Masukkan Nama: ");
        String name = input.next();
        Date registrationDate = new Date();
        String accountNumber;
        do {
            accountNumber = generateAccountNumber();
        } while (findAccount(accountNumber) != null);
        System.out.print("Masukkan Balance: ");
        double balance = input.nextDouble();
        Account account = new Account(name, accountNumber, balance, registrationDate);
        accounts[numAccounts++] = account;

        System.out.println("Nomor Akun Anda : " + accountNumber);
        System.out.println("Akun berhasil didaftarkan pada tanggal : " + registrationDate);
    }

    private static void kirimAkun() {
        System.out.print("Masukkan Nomor Akun Pengirim: ");
        String senderAccountNumber = input.next();
        System.out.print("Masukkan Nomor Akun Penerima: ");
        String receiverAccountNumber = input.next();
        System.out.print("Masukkan Jumlah Uang yang Akan Dikirim: ");
        double amount = input.nextDouble();

        Account senderAccount = findAccount(senderAccountNumber);
        Account receiverAccount = findAccount(receiverAccountNumber);

        if (senderAccount == null) {
            System.out.println("Nomor Akun Pengirim tidak ditemukan!");
        } else if (receiverAccount == null) {
            System.out.println("Nomor Akun Penerima tidak ditemukan!");
        } else if (senderAccount.getBalance() < amount) {
            System.out.println("Saldo tidak cukup untuk melakukan transfer!");
        } else {
            senderAccount.setBalance(senderAccount.getBalance() - amount);
            receiverAccount.setBalance(receiverAccount.getBalance() + amount);
            System.out.println("Transaksi berhasil dilakukan!");
        }
    }

    private static void rekeningDeposito() {
        System.out.print("Masukkan Nomor Akun: ");
        String accountNumber = input.next();
        Account depositAccount = findAccount(accountNumber);
        if (depositAccount == null) {
            System.out.println("Nomor akun tidak ditemukan!");
                       
                    }
                    
                    System.out.print("Masukkan Jumlah Uang yang Ingin Disetor: ");
                    double depositAmount;
                    while (!input.hasNextDouble()) {
                        System.out.println("Jumlah uang harus angka.");
                        System.out.print("Masukkan Jumlah Uang yang Ingin Disetor: ");
                        input.next();
                    }
                    depositAmount = input.nextDouble();
                    
                    // Cek apakah jumlah uang yang dimasukkan adalah angka positif
                    if (depositAmount <= 0) {
                        System.out.println("Jumlah uang harus lebih besar dari 0!");
                       
                    }
                    depositAccount.setBalance(depositAccount.getBalance() + depositAmount);
                    System.out.println("Rekening deposito berhasil dilakukan!");
    }
    
    private static void cekSaldo() {
        System.out.print("Masukkan Nomor Akun: ");
                    String checkAccountNumber = input.next();
                    Account checkAccount = findAccount(checkAccountNumber);
                    if (checkAccount == null) {
                        System.out.println("Nomor akun tidak ditemukan!");
                    }
                    System.out.println("Saldo rekening anda " + ": " + checkAccount.getBalance());
    }
    
    static String generateAccountNumber() {
        int number = (int) (Math.random() * 900000) + 100000; // menghasilkan nomor acak 6 digit
        return String.valueOf(number);
    }


    static Account findAccount(String accountNumber) {
        for (int i = 0; i < numAccounts; i++) {
            if (accounts[i].getAccountNumber().equals(accountNumber)) {
                return accounts[i];
            }
        }
        return null;
    }
}


class Account {
    private String name;
    private String accountNumber;
    private double balance;

    public Account(String name, String accountNumber, double balance, Date registrationDate) {
        this.name = name;
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    public String getName() {
        return name;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
